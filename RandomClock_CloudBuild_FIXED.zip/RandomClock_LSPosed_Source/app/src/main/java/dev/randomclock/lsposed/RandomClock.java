package dev.randomclock.lsposed;

import android.view.View;
import android.widget.TextView;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.util.Collections;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

public final class RandomClock implements IXposedHookLoadPackage {
    private static final long INTERVAL_MS = 100L;
    private static final int SYMBOL_COUNT = 6;
    private static final String SYMBOLS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789@#$%&*!?";
    private static final Random RANDOM = new Random();
    private static final Map<TextView, Runnable> RUNNERS =
            Collections.synchronizedMap(new WeakHashMap<TextView, Runnable>());

    @Override public void handleLoadPackage(final XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        if (lp.processName != null && !lp.packageName.equals(lp.processName)) return;
        XposedBridge.log("RandomClock v2: loaded in " + lp.processName);

        XposedBridge.hookAllMethods(View.class, "onAttachedToWindow", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                if (!(p.thisObject instanceof TextView)) return;
                TextView tv = (TextView) p.thisObject;
                if (isClockCandidate(tv)) {
                    XposedBridge.log("RandomClock v2: clock candidate "
                            + tv.getClass().getName() + " id=" + resourceName(tv));
                    start(tv);
                }
            }
        });
        XposedBridge.hookAllMethods(View.class, "onDetachedFromWindow", new XC_MethodHook() {
            @Override protected void afterHookedMethod(MethodHookParam p) {
                if (p.thisObject instanceof TextView) stop((TextView) p.thisObject);
            }
        });
    }

    private static String resourceName(TextView v) {
        try {
            int id = v.getId();
            return id == View.NO_ID ? "no-id" : v.getResources().getResourceEntryName(id);
        } catch (Throwable t) { return "unknown"; }
    }

    private static boolean isClockCandidate(TextView v) {
        return resourceName(v).toLowerCase().contains("clock")
                || v.getClass().getName().toLowerCase().contains("clock");
    }

    private static void start(final TextView view) {
        synchronized (RUNNERS) {
            if (RUNNERS.containsKey(view)) return;
            Runnable runner = new Runnable() {
                @Override public void run() {
                    if (!view.isAttachedToWindow()) { stop(view); return; }
                    try { view.setText(randomSymbols()); }
                    catch (Throwable t) {
                        XposedBridge.log("RandomClock v2: setText failed: " + t);
                        stop(view);
                        return;
                    }
                    view.postDelayed(this, INTERVAL_MS);
                }
            };
            RUNNERS.put(view, runner);
            view.post(runner);
        }
    }

    private static void stop(TextView view) {
        synchronized (RUNNERS) {
            Runnable r = RUNNERS.remove(view);
            if (r != null) view.removeCallbacks(r);
        }
    }

    private static String randomSymbols() {
        StringBuilder b = new StringBuilder(SYMBOL_COUNT);
        synchronized (RANDOM) {
            for (int i = 0; i < SYMBOL_COUNT; i++)
                b.append(SYMBOLS.charAt(RANDOM.nextInt(SYMBOLS.length())));
        }
        return b.toString();
    }
}
