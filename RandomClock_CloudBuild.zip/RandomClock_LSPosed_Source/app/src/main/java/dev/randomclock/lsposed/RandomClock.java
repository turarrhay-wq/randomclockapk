package dev.randomclock.lsposed;

import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import java.util.Collections;
import java.util.Map;
import java.util.Random;
import java.util.WeakHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class RandomClock implements IXposedHookLoadPackage {
    private static final long INTERVAL_MS = 100L;
    private static final int SYMBOL_COUNT = 6;
    private static final String SYMBOLS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789@#$%&*!?";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Random RANDOM = new Random();
    private static final Map<TextView, Runnable> RUNNERS =
            Collections.synchronizedMap(new WeakHashMap<TextView, Runnable>());

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;

        XposedBridge.hookAllMethods(View.class, "onAttachedToWindow",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (!(param.thisObject instanceof TextView)) return;
                        TextView view = (TextView) param.thisObject;
                        if (isClockView(view)) start(view);
                    }
                });

        XposedBridge.hookAllMethods(View.class, "onDetachedFromWindow",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        if (param.thisObject instanceof TextView) {
                            stop((TextView) param.thisObject);
                        }
                    }
                });
    }

    private static boolean isClockView(TextView view) {
        try {
            int id = view.getId();
            if (id != View.NO_ID) {
                String entry = view.getResources().getResourceEntryName(id);
                if (entry != null && entry.toLowerCase().contains("clock")) return true;
            }
        } catch (Throwable ignored) { }

        String className = view.getClass().getName().toLowerCase();
        return className.contains("clock");
    }

    private static void start(final TextView view) {
        synchronized (RUNNERS) {
            if (RUNNERS.containsKey(view)) return;

            Runnable runner = new Runnable() {
                @Override
                public void run() {
                    if (!view.isAttachedToWindow()) {
                        stop(view);
                        return;
                    }
                    try {
                        view.setText(randomSymbols());
                    } catch (Throwable ignored) { }
                    MAIN.postDelayed(this, INTERVAL_MS);
                }
            };
            RUNNERS.put(view, runner);
            MAIN.post(runner);
        }
    }

    private static void stop(TextView view) {
        synchronized (RUNNERS) {
            Runnable runner = RUNNERS.remove(view);
            if (runner != null) MAIN.removeCallbacks(runner);
        }
    }

    private static String randomSymbols() {
        StringBuilder out = new StringBuilder(SYMBOL_COUNT);
        for (int i = 0; i < SYMBOL_COUNT; i++) {
            out.append(SYMBOLS.charAt(RANDOM.nextInt(SYMBOLS.length())));
        }
        return out.toString();
    }
}
